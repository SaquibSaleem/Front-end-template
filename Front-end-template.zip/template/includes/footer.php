<footer>
   <div class="container">
      <div class="row">
         <div class="col-md-4">
            <div class="widget">
               
            </div>
         </div>
         <div class="col-md-4">
            <div class="widget">
               
            </div>
         </div>
         <div class="col-md-4">
            <div class="widget">
               
            </div>
         </div>
      </div>
      
   </div>
</footer>
<div class="copyright text-center">
   <div class="container">
      <p>All Rights Reserved</p>
   </div>
</div>